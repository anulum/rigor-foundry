module example.com/rigor-lockfile-fixture-go

go 1.16

require (
	example.com/local v0.0.0
	github.com/pkg/errors v0.9.1
	github.com/stretchr/testify v1.7.0
	golang.org/x/text v0.3.6
)

replace example.com/local => ./local
