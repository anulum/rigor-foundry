module example.com/rigor-lockfile-fixture-go-replace

go 1.27

require github.com/pkg/errors v0.9.1

replace github.com/pkg/errors v0.9.1 => github.com/pkg/errors v0.8.1
