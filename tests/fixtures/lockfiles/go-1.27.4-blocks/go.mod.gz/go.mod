module example.com/rigor-lockfile-fixture-go

go 1.27

require (
	example.com/local v0.0.0
	github.com/pkg/errors v0.9.1
	github.com/stretchr/testify v1.7.0
	golang.org/x/text v0.3.6
)

require (
	github.com/davecgh/go-spew v1.1.0 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	gopkg.in/yaml.v3 v3.0.0-20200313102051-9f266ea9e77c // indirect
)

replace example.com/local => ./local

tool (
	example.com/local/cmd/first
	example.com/local/cmd/second
)

godebug (
	panicnil=1
	winsymlink=0
)

ignore (
	./build
	./node_modules
)
